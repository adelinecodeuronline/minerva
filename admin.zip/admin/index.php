<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 

} else {
            
    $req = $db->prepare('SELECT * FROM users
    INNER JOIN tickets ON tickets.user_id = users.user_id');
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC);

} 

//Filtres
if (isset($_POST['new'])) { //nouveaux tickets
    $nouveaux = 'new';     
    $req = $db->prepare("SELECT * FROM users
    INNER JOIN tickets ON tickets.user_id = users.user_id
    WHERE ticket_statut LIKE '%$nouveaux%'");
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC);

} else if (isset($_POST['mestickets'])) { //tickets de l'admin
    $mestickets = 3;     
    $req = $db->prepare("SELECT * FROM users
    INNER JOIN tickets ON tickets.user_id = users.user_id
    WHERE users.user_id LIKE '%$mestickets%'");
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC);

} else if (isset($_POST['ticketsfermes'])) { //tickets clôturés
    $ticketsfermes = 'resolu';     
    $req = $db->prepare("SELECT * FROM users
    INNER JOIN tickets ON tickets.user_id = users.user_id
    WHERE ticket_statut LIKE '%$ticketsfermes%'");
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC);

} else if(isset($_POST['urgents'])) { //tickets urgents
        
    $req = $db->prepare("SELECT * FROM users
    INNER JOIN tickets ON tickets.user_id = users.user_id
    ORDER BY ticket_date ASC");
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC); 
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="./assets/css/dashboard-tickets-admin-mobile.css">
    <link rel="stylesheet" href="./assets/css/dashboard-tickets-admin.css">

    <script src="./assets/js/dashboard.js" defer></script>
    <script src="./assets/js/sidebar.js" defer></script>   

    <title>MINERVA 🦉 | Tickets</title>
</head>

<body>
    <div id="box">
        <div class="sidebar"><!--SIDEBAR-->
        <!--menu burger-->
            <img id="burger" src="./assets/img/burger-vertical.svg" alt="Menu burger">
            <img id="burgerHoriz" src="./assets/img/burger-horizontal.svg" alt="Menu burger horizontal">
            <!--image profil-->
            <?php 
            $req = $db->prepare("SELECT * FROM users
             WHERE users.user_role = 'admin'");
            $req->execute();
            $userp = $req->fetchAll(PDO::FETCH_ASSOC);            
            ?>

            <?php foreach ($userp as $up):  ?>
            <img id="profil" src="../assets/uploads/<?php echo $up['user_imageprofil']; ?>" alt="Image profil">
            <?php endforeach; ?>
        
        <!-----liens-------->
        <ul class="sidebar__menu">
            <a href="./index.php">
                <div class="sidebar__menu__div" id="tickets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-ticket.svg" alt="Tickets">
                        <a class="sidebar__menu__div__links" href="#">Tickets</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-clients-admin.php">
                <div class="sidebar__menu__div">
                    <li id="clients">
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-clients.svg" alt="Clients">
                        <a class="sidebar__menu__div__links" href="#">Clients</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-projets-admin.php">
                <div class="sidebar__menu__div">
                    <li id="projets">
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-projets.svg" alt="Projets">
                        <a class="sidebar__menu__div__links" href="#">Projets</a>
                    </li>  
                </div> 
            </a>
        </ul> 
        
        <a class="sidebar__btn-side" href="#">+</a>
        </div>
        <!--FIN SIDEBAR-->

        <div id="content">
            <header>
                <a href="./logout.php" class="logout"><img src="../assets/img/log-out.svg" alt="logout"></a>
                <form action="resultats.php" method="GET" name="">
                    <input id="search" type="search" name="search" placeholder="Rechercher..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </form>
            
                <div class="filtres">
                    <form action="index.php" method="POST">                                        
                        <div class="filtres__parametres">                    
                            <img class="filtres__parametres__visuels" src="./assets/img/icone-nouveaux.svg" alt="Nouveaux tickets">
                            <button type="submit" name="new" class="filter-head">Nouveaux</button>                   
                        </div>
                    </form>                    

                    <form action="index.php" method="POST"> 
                        <div class="filtres__parametres">
                            <img class="filtres__parametres__visuels" src="./assets/img/icone-mestickets.svg" alt="Mes tickets">
                            <button type="submit" name="mestickets" class="filter-head">Mes tickets</button>
                        </div>
                    </form>                      

                    <form action="index.php" method="POST"> 
                        <div class="filtres__parametres">
                            <img class="filtres__parametres__visuels" src="./assets/img/icone-ticketsfermes.svg" alt="Tickets fermés">
                            <button type="submit" name="ticketsfermes" class="filter-head">Tickets fermés</button>
                        </div>
                    </form> 

                    <form action="index.php" method="POST">
                        <div class="filtres__parametres">
                            <img class="filtres__parametres__visuels" src="./assets/img/icone-lesplusurgents.svg" alt="Les plus urgents">
                            <button type="submit" name="urgents" class="filter-head">Les + urgents</button>
                        </div>
                    </form>
                </div>
            </header>
            
            <main>       
               <div class="grid"><!--TABLEAU-->
                   <!--Titres généraux--->
                    <div class="grid__titre1">N°</div>
                    <div class="grid__titre2">Statut</div>
                    <div class="grid__titre2-1"></div>
                    <div class="grid__titre3">Titre</div>  
                    <div class="grid__titre4">Auteur</div>
                    <div class="grid__titre5">Date</div>
                    <div class="grid__titre6">Tags</div>
                    <div class="grid__titre7"></div>
                    <div class="grid__titre8"></div>
                    <!--Ligne--->

                <?php foreach ($user as $u):  ?>                    
                        
                        <div class="grid__nb"><a href="detail-ticket.php?id=<?php echo htmlspecialchars($u['ticket_id']) ?>"><?php echo $u['ticket_id'] ?></a></div>
                        <div class="grid__statut <?php echo $u['ticket_statut'] ?>"><img class="grid__statut-img" src="./assets/img/statutouvert.svg" class="statut" alt="Statut"></div>
                        <div class="grid__fleche" data-id="tab<?php echo $u['ticket_id'] ?>"><img class="grid__fleche-img" src="./assets/img/fleche.svg" alt="Dérouler"></div>
                        <div class="grid__titre tab<?php echo $u['ticket_id'] ?>"><?=htmlspecialchars($u['ticket_titre'], ENT_QUOTES)?></div>
                        <div class="grid__auteur <?php echo $u['user_name'] ?> tab<?php echo $u['ticket_id'] ?>"><?php echo $u['user_name'] ?></div>
                        <div class="grid__date tab<?php echo $u['ticket_id'] ?>"><?php echo $u['ticket_date'] ?></div>
                        <div class="grid__tags tab<?php echo $u['ticket_id'] ?>"><?php echo $u['ticket_origineprob'] ?></div>
                        <div class="grid__modifier tab<?php echo $u['ticket_id'] ?>"><a href="dashboard-modification-tickets.php?id=<?php echo htmlspecialchars($u['ticket_id']) ?>"><img class="grid__mdf-img" src="./assets/img/icone-modifier.svg" alt="Modifier"></a></div>
                        <div class="grid__supprimer tab<?php echo $u['ticket_id'] ?>"><a href="suppression-ticket.php?id=<?php echo htmlspecialchars($u['ticket_id']) ?>"><img class="grid__suppr-img" src="./assets/img/icone-supprimer.svg" alt="Supprimer"></a></div>
                  
                <?php endforeach; ?>
                    <!--Fin Ligne--->
                </div>

            <!--MODAL CREATION TICKET-->
           
                <div class="modal-crea-modif">
                    <img class="fermeture" src="./assets/img/fermer-modal.svg" alt="fermer">

                    <form action="validation-ticket.php" method="post" enctype="multipart/form-data">
                        <div id="main-infos">                            
                            <label>Client</label> 
                            <input type="text" name="client">
                            <label>Titre</label> 
                            <input type="text" name="titre">
                            <label>Ticket</label> 
                            <textarea name="ticket"></textarea>                            
                            <!--tags-->
                            <label>Origine problème</label>
                               <select name="origine_prob" id="prob">
                                    <option value="choix">Faites un choix</option>
                                    <option value="visuel">Visuel</option>
                                    <option value="technique">Technique</option>
                                    <option value="hébergement">Hébergement</option>
                                    <option value="mail">Mail</option>
                                    <option value="autre">Autre</option>
                                </select>                                                       
                        </div>

                           <div class="options">
                               <label>Importance</label>
                               <select name="importance" id="impt">
                                    <option value="choix importance">Choisir l'importance</option>
                                    <option value="important">Important</option>
                                    <option value="moyen">Moyen</option>
                                    <option value="faible">Faible</option>
                                </select>

                                <input id="file" type="file" name="fichier">
                                <label for="file" id="file-button">Attacher un fichier</label>
                                <div id="file-upload-filename"></div>
                           </div>

                           <div id="buttons">
                               <button id="enregistrer-btn" name="enrg-ticket">enregistrer</button>
                               <button id="supprimer-btn" formaction="suppression-ticket.php?id=<?php echo htmlspecialchars($u['ticket_id']) ?>">supprimer</button>                               
                           </div>                          
                    </form>            
                </div>
            </main>   
        </div>
    </div> 
</body>
</html>