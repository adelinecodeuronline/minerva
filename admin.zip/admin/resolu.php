<?php

session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit;  
}


if(isset($_POST['resolu'])) {
    $get_id = $_GET['id'];
    $statut = 'resolu';

    $result = $db->prepare("UPDATE tickets SET ticket_statut = '$statut' WHERE id = '$get_id' ");
    $result->execute();
    header("location: index.php");
}

