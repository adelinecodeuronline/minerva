<?php
session_start(); 

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 
}

require_once '../config.php';

//Modification d'un compte client

$get_id=$_GET['id'];
$nom= $_POST['nom'];
$entreprise= $_POST['entreprise'];
$tel= $_POST['tel'];
$email = $_POST['email'];
$adresse = $_POST['adresse'];

$tmpName = $_FILES['fichier']['tmp_name'];
$name = $_FILES['fichier']['name']; 
$upload_dir='../assets/uploads/';

$uniqueName = uniqid('', true);        
$extension = pathinfo($name, PATHINFO_EXTENSION);
$unique_file = $uniqueName.".".$extension;
move_uploaded_file($tmpName, '../assets/uploads/'.$unique_file);

$result = $db->prepare("UPDATE users SET user_name = '$nom', user_entreprise ='$entreprise', user_email ='$email', user_imageprofil = '$unique_file', user_tel ='$tel', user_adresse ='$adresse' WHERE user_id = '$get_id' ");
$result->execute();
header("location: dashboard-clients-admin.php");






