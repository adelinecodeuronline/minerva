<?php
require_once '../config.php';

//Création d'une fiche projet
if(isset($_POST['enrg-projet'])) {

    $importance = $_POST['importance'];
    $client = $_POST['client'];
    $type = $_POST['type']; 
    $description = $_POST['description'];
    
    $tmpName = $_FILES['fichier']['tmp_name'];
    $name = $_FILES['fichier']['name'];
    //$error = $_FILES['fichier']['error'];

    //if($error == 0) {
  
    $uniqueName = uniqid('', true);        
    $extension = pathinfo($name, PATHINFO_EXTENSION);      
    //génération uniqid : 5f586bf96dcd38.73540086
    $unique_file = $uniqueName.".".$extension;        
    //$unique_file = 5f586bf96dcd38.73540086.jpg
    move_uploaded_file($tmpName, './assets/uploads/'.$unique_file);

    $req = $db->prepare('INSERT INTO projets (projet_importance, projet_type, projet_description, projet_visuel, projet_client, projet_date) VALUES (?, ?, ?, ?, ?, NOW())');
    $req->execute([$importance, $type, $description, $unique_file, $client]);   
    
    header('Location: dashboard-projets-admin.php');

    //}

} 
