<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 
}

//Modification d'une fiche projet

$sql = "UPDATE projets SET projet_importance = :importance, 
         projet_type = :type, 
         projet_description = :description,
         projet_client = :client
         WHERE projet_id = :get_id";
      
$stmt = $db->prepare($sql);                                  
$stmt->bindParam(':importance', $_POST['importance'], PDO::PARAM_STR);     
$stmt->bindParam(':type', $_POST['type'], PDO::PARAM_STR);    
$stmt->bindParam(':description', $_POST['description'], PDO::PARAM_STR);
$stmt->bindParam(':client', $_POST['client'], PDO::PARAM_STR);
$stmt->bindParam(':get_id', $_GET['id'], PDO::PARAM_INT);   
$stmt->execute();

header("location: dashboard-projets-admin.php");





