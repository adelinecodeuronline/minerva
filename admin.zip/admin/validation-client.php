<?php
session_start();
require_once '../config.php';


if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 
}

//Création d'un compte client
if(isset($_POST['enrg-client'])) {

    $nom = $_POST['nom'];
    $entreprise = $_POST['entreprise'];
    $tel = $_POST['tel']; 
    $email = $_POST['email'];
    $adresse = $_POST['adresse'];  
    $role = 'user'; 

    $tmpName = $_FILES['fichier']['tmp_name'];
    $name = $_FILES['fichier']['name'];   
  
    $uniqueName = uniqid('', true);        
    $extension = pathinfo($name, PATHINFO_EXTENSION);      
    //génération uniqid : 5f586bf96dcd38.73540086
    $unique_file = $uniqueName.".".$extension;        
    //$unique_file = 5f586bf96dcd38.73540086.jpg
    move_uploaded_file($tmpName, '../assets/uploads/'.$unique_file);

    $req = $db->prepare("INSERT INTO users (user_role, user_name, user_entreprise, user_email, user_imageprofil, user_tel, user_adresse) VALUES ('$role', '$nom', '$entreprise', '$email', '$unique_file', '$tel', '$adresse' )");
    $req->execute();

    
    header('Location: dashboard-clients-admin.php');

  

} 
