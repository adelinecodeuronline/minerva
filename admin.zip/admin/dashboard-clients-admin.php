<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 

} else {    
         
    $req = $db->prepare("SELECT * FROM users
    LEFT JOIN tickets ON tickets.user_id = users.user_id");
    $req->execute();
    $user = $req->fetchAll(PDO::FETCH_ASSOC);

} 

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="./assets/css/dashboard-clients-admin-mobile.css">
    <link rel="stylesheet" href="./assets/css/dashboard-clients-admin.css">

    <script src="./assets/js/dashboard-clients.js" defer></script>
    <script src="./assets/js/sidebar.js" defer></script>   

    <title>MINERVA 🦉 | Clients</title>
</head>

<body>
    <div id="box">
        <div class="sidebar"><!--SIDEBAR-->
        <!--menu burger-->
            <img id="burger" src="./assets/img/burger-vertical.svg" alt="Menu burger">
            <img id="burgerHoriz" src="./assets/img/burger-horizontal.svg" alt="Menu burger horizontal">
            <!--image profil-->
            <?php 
            $req = $db->prepare("SELECT * FROM users
             WHERE users.user_role = 'admin'");
            $req->execute();
            $userp = $req->fetchAll(PDO::FETCH_ASSOC);            
            ?>

            <?php foreach ($userp as $up):  ?>
            <img id="profil" src="../assets/uploads/<?php echo $up['user_imageprofil']; ?>" alt="Image profil">
            <?php endforeach; ?>
        
        <!-----liens-------->
        <ul class="sidebar__menu">
            <a href="./index.php">
                <div class="sidebar__menu__div" id="tickets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-ticket.svg" alt="Tickets">
                        <a class="sidebar__menu__div__links" href="#">Tickets</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-clients-admin.php">
                <div class="sidebar__menu__div" id="clients">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-clients.svg" alt="Clients">
                        <a class="sidebar__menu__div__links" href="#">Clients</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-projets-admin.php">
                <div class="sidebar__menu__div" id="projets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-projets.svg" alt="Projets">
                        <a class="sidebar__menu__div__links" href="#">Projets</a>
                    </li>  
                </div> 
            </a>
        </ul> 
        
        <a class="sidebar__btn-side" href="#">+</a>
        </div>
        <!--FIN SIDEBAR-->

        <div id="content">
            <header>
                <a href="./logout.php" class="logout"><img src="../assets/img/log-out.svg" alt="logout"></a>
                <form action="resultats.php" method="GET" name="">
                    <input id="search" type="search" name="search" placeholder="Rechercher..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </form>              
            </header>
            
            <main>       
               <div class="grid"><!--TABLEAU-->
                   <!--Titres généraux--->
                    <div class="grid__titre1">Nom</div>
                    <div class="grid__titre2">Logo</div>
                    <div class="grid__titre2-1">Email</div>
                    <div class="grid__titre3">Tél</div>  
                    <div class="grid__titre4">Tickets</div>
                    <div class="grid__titre7"></div>
                    <div class="grid__titre8"></div>
                    <!--Ligne--->

                <?php foreach ($user as $u):  ?>   

                    <div class="grid__nom"><a href="dashboard-modification-clients.php?id=<?php echo htmlspecialchars($u['user_id']) ?>"><?php echo $u['user_name'] ?></a></div>
                    <div class="grid__logo"><img class="grid__logo-img" src="../assets/uploads/<?php echo $u['user_imageprofil']; ?>" alt="logo"></div>
                    <div class="grid__email"><?php echo $u['user_email'] ?></div>
                    <div class="grid__tel"><?php echo $u['user_tel'] ?></div>
                    <div class="grid__tickets"><?php echo $u['ticket_id'] ?></div>
                    
                    <div class="grid__modifier"><a href="dashboard-modification-clients.php?id=<?php echo htmlspecialchars($u['user_id']) ?>"><img class="grid__mdf-img" src="./assets/img/icone-modifier.svg" alt="Modifier"></a></div>
                    <div class="grid__supprimer"><a href="suppression-compteclient.php?id=<?php echo htmlspecialchars($u['user_id']) ?>"><img class="grid__suppr-img" src="./assets/img/icone-supprimer.svg" alt="Supprimer"></a></div>
                <?php endforeach; ?>   
                    <!--Fin Ligne--->                    
                </div>

            <!--MODAL CREATION FICHE CLIENT-->
                <div class="modal-fiche-client">
                    <img class="fermeture" src="./assets/img/fermer-modal.svg" alt="fermer">
                    <div>                    
                        <div class="modal-fiche-client__form">
                            <form action="validation-client.php" method="post" enctype="multipart/form-data">
                                <div id="main-infos">                            
                                    <label>Nom</label> 
                                    <input type="text" name="nom">
                                    <label>Entreprise</label> 
                                    <input type="text" name="entreprise">
                                    <label>Tél</label> 
                                    <input type="tel" name="tel">
                                    <label>Email</label> 
                                    <input type="email" name="email">
                                    <label>Adresse</label> 
                                    <input type="text" name="adresse">                                
                                </div>

                                <div id="options">                          
                                    <input id="file" type="file" name="fichier">
                                    <label for="file" id="file-button">Attacher un fichier</label>
                                    <div id="file-upload-filename"></div>
                                </div>

                                <div id="buttons">
                                    <button id="enregistrer-btn" name="enrg-client">enregistrer</button>
                                    <button id="supprimer-btn" formaction="suppression-compteclient.php?id=<?php echo htmlspecialchars($u['user_id']) ?>">supprimer</button>
                                </div>                          
                            </form>

                            <div class="modal-fiche-client__form__links">
                                <a id="crea-contact" href="#">| Ajouter un contact rattaché</a>
                                <a id="crea-projet" href="#">Créer une fiche projet |</a>
                            </div>
                        </div>
                    </div>                   
                </div>  
                
                <!--MODAL CREATION FICHE PROJET-->
                <div class="modal-fiche-projet">
                    <img class="fermeture" src="./assets/img/fermer-modal.svg" alt="fermer">
                    
                        <div class="modal-fiche-projet__form">
                            <form action="validation-projet.php" method="post" enctype="multipart/form-data">
                                <div id="main-infos"> 
                                    <label>Importance</label>
                                    <select name="importance" id="impt">
                                        <option value="">--Choisir une option--</option>
                                        <option value="important">Important</option>
                                        <option value="moyen">Moyen</option>
                                        <option value="faible">Faible</option>
                                    </select>                           
                                    <label>Client</label> 
                                    <input type="text" name="client">
                                    <label>Type</label> 
                                    <input type="text" name="type">
                                    <label>Description</label> 
                                    <textarea name="description"></textarea>                               
                                </div>

                                <div id="options">                          
                                    <input id="file" type="file" name="fichier">
                                    <label for="file" id="file-button">Attacher un fichier</label>
                                    <div id="file-upload-filename"></div>
                                </div>

                                <div id="buttons">
                                    <button id="enregistrer-btn">enregistrer</button>
                                    <button id="supprimer-btn">supprimer</button>
                                </div>                          
                            </form>
                        </div>
                    </div>                   
                </div>                
            </main>   
        </div>
    </div> 
</body>
</html>