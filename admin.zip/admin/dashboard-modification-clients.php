<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 
}

$nom = $_GET['id'];

$req = $db->prepare("SELECT * FROM users WHERE user_id= ?");
$req->execute([$nom]);
$user = $req->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="./assets/css/dash-modif-clients-admin-mobile.css">
    <link rel="stylesheet" href="./assets/css/dash-modif-clients-admin.css">
    
    <script src="./assets/js/sidebar.js" defer></script>  
    <script src="./assets/js/modification-tickets.js" defer></script> 

    <title>MINERVA 🦉 | Modification fiche client</title>
</head>

<body>
    <div id="box">
        <div class="sidebar"><!--SIDEBAR-->
        <!--menu burger-->
            <img id="burger" src="./assets/img/burger-vertical.svg" alt="Menu burger">
            <img id="burgerHoriz" src="./assets/img/burger-horizontal.svg" alt="Menu burger horizontal">
            <!--image profil-->
            <?php 
            $req = $db->prepare("SELECT * FROM users
             WHERE users.user_role = 'admin'");
            $req->execute();
            $userp = $req->fetchAll(PDO::FETCH_ASSOC);            
            ?>

            <?php foreach ($userp as $up):  ?>
            <img id="profil" src="../assets/uploads/<?php echo $up['user_imageprofil']; ?>" alt="Image profil">
            <?php endforeach; ?>
        <!-----liens-------->
        <ul class="sidebar__menu">
            <a href="./index.php">
                <div class="sidebar__menu__div" id="tickets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-ticket.svg" alt="Tickets">
                        <a class="sidebar__menu__div__links" href="#">Tickets</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-clients-admin.php">
                <div class="sidebar__menu__div" id="clients">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-clients.svg" alt="Clients">
                        <a class="sidebar__menu__div__links" href="#">Clients</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-projets-admin.php">
                <div class="sidebar__menu__div" id="projets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-projets.svg" alt="Projets">
                        <a class="sidebar__menu__div__links" href="#">Projets</a>
                    </li>  
                </div> 
            </a>
        </ul> 
        
        <a class="sidebar__btn-side" href="#">+</a>
        </div>
        <!--FIN SIDEBAR-->

        <div id="content">
            <header>
                <form action="resultats.php" method="GET" name="">
                    <input id="search" type="search" name="search" placeholder="Rechercher..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </form>             
            </header>
            
            <main>       
               
            <!--MODAL MODIFICATION FICHE CLIENT-->
                <div class="modal-fiche-client">                   
                    <div>
                    <?php foreach ($user as $u):  ?>
                        <div class="modal-fiche-client__infos">
                            <div id="informations-client">
                                <p class="modal-fiche-client__infos__nom"><?php echo $u['user_name']; ?></p>
                                <p class="modal-fiche-client__infos__contact-ratt">Contact rattaché</p>                        
                                <p class="modal-fiche-client__infos__tickets">N° ticket : <?php echo $u['ticket_id']; ?></p>
                                <p class="modal-fiche-client__infos__nom-entr"><?php echo $u['user_entreprise']; ?></p>
                                <p class="modal-fiche-client__infos__coord"><?php echo $u['user_tel']; ?>
                                <?php echo $u['user_adresse']; ?>
                            </p>
                            </div>

                            <div id="logo-client">
                                <p class="modal-fiche-client__infos__titre">Logo</p>
                                <img class="modal-fiche-client__infos__logo" src="../assets/uploads/<?php echo $u['user_imageprofil']; ?>" alt="Logo client">
                            </div>
                        </div>                    

                        <div class="modal-fiche-client__form">
                        
                            <form action="modification-client.php<?php echo '?id='.$u['user_id']; ?>" method="post" enctype="multipart/form-data">
                                <div id="main-infos">                            
                                    <label>Nom</label> 
                                    <input type="text" name="nom" value="<?php echo $u['user_name']; ?>">
                                    <label>Entreprise</label> 
                                    <input type="text" name="entreprise" value="<?php echo $u['user_entreprise']; ?>">
                                    <label>Tél</label> 
                                    <input type="tel" name="tel" value="<?php echo $u['user_tel']; ?>">
                                    <label>Email</label> 
                                    <input type="email" name="email" value="<?php echo $u['user_email']; ?>">
                                    <label>Adresse</label> 
                                    <input type="text" name="adresse" value="<?php echo $u['user_adresse']; ?>">                                
                                </div>

                                <div id="options">                          
                                    <input id="file" type="file" name="fichier" value="<?php echo $u['user_imageprofil']; ?>">
                                    <label for="file" id="file-button">Attacher un fichier</label>
                                    <div id="file-upload-filename"><?php echo $u['user_imageprofil']; ?></div>
                                </div>

                                <div id="buttons">
                                    <button id="enregistrer-btn">actualiser</button>
                                    <button formaction= "suppression-compteclient.php?id=<?php echo htmlspecialchars($u['user_id']) ?>" id="supprimer-btn">supprimer</button>
                                </div>                          
                            </form>                            
                        </div>
                        <?php endforeach; ?>  
                    </div>                   
                </div>                 
                
            </main>   
        </div>
    </div> 
</body>
</html>