
//Bouton upload de fichier [FORMULAIRE MODAL MODIFICATION TICKET]
let input = document.querySelector('#file');
input.addEventListener('change', showFileName);
/*Affiche le nom du fichier téléchargé*/
function showFileName(event) {
    let infoArea = document.querySelector('#file-upload-filename');
    let input = event.srcElement; 
    let fileName = input.files[0].name; 

    infoArea.textContent = 'Nom du fichier : ' + fileName;
}


