
////////////////////////////////////////////////////////////////////////////
////FLECHE DEROULER TABLEAU (mobile)

  document.querySelectorAll('.grid__fleche').forEach(fleche => {
    fleche.addEventListener('click', displayInfo);
  });
 
function displayInfo() {
  let titres = document.querySelectorAll('.grid__titre');
  let auteurs = document.querySelectorAll('.grid__auteur');
  let dates = document.querySelectorAll('.grid__date');
  let tags = document.querySelectorAll('.grid__tags');
  let modifs = document.querySelectorAll('.grid__modifier');
  let supprs = document.querySelectorAll('.grid__supprimer');
  titres.forEach(oneTitre => {
    oneTitre.classList.remove ('open');
  });

  auteurs.forEach(oneAuteur => {
    oneAuteur.classList.remove ('open');
  });

  dates.forEach(oneDate => {
    oneDate.classList.remove ('open');
  });

  tags.forEach(oneTag => {
    oneTag.classList.remove ('open');
  });

  modifs.forEach(oneModif => {
    oneModif.classList.remove ('open');
  });

  supprs.forEach(oneSuppr => {
    oneSuppr.classList.remove ('open');
  });
  
  let id = this.dataset.id;
  document.querySelectorAll(`.${id}`).forEach(cl => {
  cl.classList.add('open');  
});
}



//CREATION TICKET
//Ouverture modal crea ticket avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-crea-modif');
  modalCrea.style.display = 'block';
}


/////Fermeture modal
document.querySelectorAll('.fermeture').forEach (cross => {
  cross.addEventListener('click', removeModal);
});

function removeModal() {
  let modalOpened = document.querySelector('.modal-crea-modif');
  modalOpened.style.display = 'none';  
}

//Bouton upload de fichier [FORMULAIRE MODAL CREATION TICKET]
let input = document.querySelector('#file');
input.addEventListener('change', showFileName);
/*Affiche le nom du fichier téléchargé*/
function showFileName(event) {
    let infoArea = document.querySelector('#file-upload-filename');
    let input = event.srcElement; 
    let fileName = input.files[0].name; 

    infoArea.textContent = 'Nom du fichier : ' + fileName;
}

  