
//CREATION fiche client
//Ouverture modal crea fiche client avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-fiche-client');
    modalCrea.style.display = 'block';  
}

//Ouverture modal crea PROJET avec lien dans modal fiche client
document.querySelector('#crea-projet').addEventListener('click', displayModalProject);

function displayModalProject() {
  let modalCreaProj = document.querySelector('.modal-fiche-projet');
  let closeClient = document.querySelector('.modal-fiche-client');
    modalCreaProj.style.display = 'block'; 
    closeClient.style.display = 'none';   
}

/////Fermeture modals
document.querySelectorAll('.fermeture').forEach (cross => {
  cross.addEventListener('click', removeModal);
});

function removeModal() {
  let modalOpened = document.querySelector('.modal-fiche-client');
  let modalOpened2 = document.querySelector('.modal-fiche-projet');
  modalOpened.style.display = 'none';
  modalOpened2.style.display = 'none'; 
}


//Bouton upload de fichier [FORMULAIRE MODAL CREATION / MODIFICATION TICKET]
let input = document.querySelector('#file');
input.addEventListener('change', showFileName);
/*Affiche le nom du fichier téléchargé*/
function showFileName(event) {
    let infoArea = document.querySelector('#file-upload-filename');
    let input = event.srcElement; 
    let fileName = input.files[0].name; 

    infoArea.textContent = 'Nom du fichier : ' + fileName;
}

