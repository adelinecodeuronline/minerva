//CREATION TICKET
//Ouverture modal crea ticket avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-crea-modif');
  modalCrea.style.display = 'block';
}


/////Fermeture modal
document.querySelectorAll('.fermeture').forEach (cross => {
  cross.addEventListener('click', removeModal);
});

function removeModal() {
  let modalOpened = document.querySelector('.modal-crea-modif');
  modalOpened.style.display = 'none';  
}