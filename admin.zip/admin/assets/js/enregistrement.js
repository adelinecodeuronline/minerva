let nom = document.querySelector('#nom');
let entreprise = document.querySelector('#entreprise');
let email = document.querySelector('#email');
let identifiant = document.querySelector('#identifiant');
let mdp = document.querySelector('#pswd');
let submit = document.querySelector('button');

nom.addEventListener('change', verifNom);
entreprise.addEventListener('change', verifEntreprise);
email.addEventListener('change', verifEmail);
identifiant.addEventListener('change', verifId);
mdp.addEventListener('change', verifPswd);
submit.addEventListener('click', validateForm);

/////////input Nom
function verifNom() {
   
    if (this.value.length >= 5) { 
        this.style.borderColor = "#05A3A0";//cyan
        
    }
    else {
        this.style.borderColor = "#BFB56A"; //jaune        
    }
}

/////////input Entreprise
function verifEntreprise() {
   
    if (this.value.length >= 5) { 
        this.style.borderColor = "#05A3A0";//cyan
        
    }
    else {
        this.style.borderColor = "#BFB56A"; //jaune        
    }
}

/////////input Email
function verifEmail() {
    if(checkEmail(this.value)) {
        this.style.borderColor = "#05A3A0";
    } else {
        this.style.borderColor = "#BFB56A";       
    }   
}

function checkEmail(mail) {
    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(mail);
}

/////////input Identifiant
function verifId() {
   
    if (this.value.length >= 5) { 
        this.style.borderColor = "#05A3A0";//cyan
        
    }
    else {
        this.style.borderColor = "#BFB56A"; //jaune        
    }
}

///////////input Password 
function verifPswd() {
    if(this.value.length >= 5) {
        this.style.borderColor = "#05A3A0";
        
    } else {
        this.style.borderColor = "#BFB56A";        
    }
}

////////////////Submit 
function validateForm() {
    let x = document.forms['enregistrement']['nom']['entreprise']['email']['identifiant']['pswd'].value;
    if (x == "") {
      alert('Tous les champs doivent être remplis');
      return false;
    } else {
        submit.submit();
    }
  }