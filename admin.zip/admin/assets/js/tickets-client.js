////////////////////////////////////////////////////////////////////////////
////FLECHE DEROULER TABLEAU (mobile)
////FLECHE DEROULER TABLEAU (mobile)
let fleches = document.getElementsByClassName('grid__fleche');
let i;

for (i = 0; i < fleches.length; i++) {
  fleches[i].addEventListener('click', function() {
    let titreTableau = document.querySelector('.grid__titre');
    let auteurTableau = document.querySelector('.grid__auteur');
    let dateTableau = document.querySelector('.grid__date');
    let empTableau = document.querySelector('.grid__emp');
    let modifTableau = document.querySelector('.grid__modifier');
    let supprTableau = document.querySelector('.grid__supprimer');
    if (titreTableau.style.display === 'block' && auteurTableau.style.display === 'block' 
    && dateTableau.style.display === 'block' && empTableau.style.display === 'block'
    && modifTableau.style.display === 'block' && supprTableau.style.display === 'block') {
      titreTableau.style.display = 'none';
      auteurTableau.style.display = 'none';
      dateTableau.style.display = 'none';
      empTableau.style.display = 'none';
      modifTableau.style.display = 'none';
      supprTableau.style.display = 'none';
    } else {
      titreTableau.style.display = 'block';
      auteurTableau.style.display = 'block';
      dateTableau.style.display = 'block';
      empTableau.style.display = 'block';
      modifTableau.style.display = 'block';
      supprTableau.style.display = 'block';
    }
  });
}
  
//CREATION TICKET
//Ouverture modal crea ticket avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-crea-modif');
  modalCrea.style.display = 'block';
}

//Ouverture modal crea/modif ticket avec pictos '...'
document.querySelectorAll('.grid__modifier').forEach (mod => {
  mod.addEventListener('click', displayModalCrea);
});

function displayModalCrea() {
  let modal = document.querySelector('.modal-crea-modif');
  modal.style.display = 'block';
}

//Ouverture modal détail ticket avec div n°
document.querySelectorAll('.grid__nb').forEach (nb => {
  nb.addEventListener('click', displayModalDetail);
});

function displayModalDetail() {
  let modalDetail = document.querySelector('.modal-detail');
  modalDetail.style.display = 'block';
}

/////Fermeture modals
document.querySelectorAll('.fermeture').forEach (cross => {
  cross.addEventListener('click', removeModal);
});

function removeModal() {
  let modalOpened = document.querySelector('.modal-crea-modif');
  let modalOpened2 = document.querySelector('.modal-detail');
  modalOpened.style.display = 'none';
  modalOpened2.style.display = 'none';
}

//Bouton upload de fichier [FORMULAIRE MODAL CREATION / MODIFICATION TICKET]
let input = document.querySelector('#file');
input.addEventListener('change', showFileName);
/*Affiche le nom du fichier téléchargé*/
function showFileName(event) {
    let infoArea = document.querySelector('#file-upload-filename');
    let input = event.srcElement; 
    let fileName = input.files[0].name; 

    infoArea.textContent = 'Nom du fichier : ' + fileName;
}

//Bouton upload de fichier [MODAL DETAIL TICKET]
let input2 = document.querySelector('#file2');
input2.addEventListener('change', showFileName2);
/*Affiche le nom du fichier téléchargé*/
function showFileName2(e) {
    let infoArea2 = document.querySelector('#file-upload-filename2');
    let input2 = e.srcElement; 
    let fileName2 = input2.files[0].name; 

    infoArea2.textContent = 'Nom du fichier : ' + fileName2;
}