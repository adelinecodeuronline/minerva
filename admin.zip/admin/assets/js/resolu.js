let clotBtn = document.querySelector('#cloturer-btn');
clotBtn.addEventListener('click', changeStatut);

function changeStatut() {
    
    let statut = document.querySelector('.statut');
    statut.src = './assets/img/statutneutre.svg';
    statut.classList.add('resolu');

}