///SIDEBAR
if (window.matchMedia("(min-width: 900px)").matches) {
    const sidebar = document.querySelector('.sidebar');
    let burgerVert = document.querySelector('#burger');
    let burgerHor = document.querySelector('#burgerHoriz');
   let profile = document.querySelector('#profil');
    
     
    sidebar.querySelector('#burger').addEventListener('click', function() {
       sidebar.classList.toggle('open', true);
       burgerHor.style.display = 'block';
       burgerVert.style.display = 'none';  
       profile.style.display = 'block';
     let menuLinks = document.querySelectorAll('.sidebar__menu__div__links');
     menuLinks.forEach(lien => {
         lien.style.opacity = '1';
     });
     let focusLink = document.querySelectorAll('.sidebar__menu__div');
     focusLink.forEach(foc => {
         foc.style.width = '16vw';
     });   
   });
   }
   
   //Fermeture sidebar
   const sidebarClose = document.querySelector('.sidebar');
   let burgerImg = document.querySelector('#burger');
   let burgerHori = document.querySelector('#burgerHoriz');
   let profileClose = document.querySelector('#profil');
   sidebarClose.querySelector('#burgerHoriz').addEventListener('click', function() {
     sidebarClose.classList.toggle('open', false);
     burgerImg.style.display = 'block';
     burgerHori.style.display = 'none';
     profileClose.style.display = 'none';
     let links = document.querySelectorAll('.sidebar__menu__div__links');
     links.forEach(link => {
         link.style.opacity = '0';
     });
     let focus = document.querySelectorAll('.sidebar__menu__div');
     focus.forEach(focusLink => {
         focusLink.style.width = '5vw';
     });   
   });