let identifiant = document.querySelector('#identifiant');
let mdp = document.querySelector('#pswd');
let submit = document.querySelector('button');

identifiant.addEventListener('change', verifId);
mdp.addEventListener('change', verifPswd);
submit.addEventListener('click', validateForm);

/////////input Identifiant
function verifId() {
   
  if (this.value.length >= 5) { 
      this.style.borderColor = "#05A3A0";//cyan
      
  }
  else {
      this.style.borderColor = "#BFB56A"; //jaune        
  }
}

///////////input Password 
function verifPswd() {
  if(this.value.length >= 5) {
      this.style.borderColor = "#05A3A0";
      
  } else {
      this.style.borderColor = "#BFB56A";        
  }
}

////////////////Submit 
function validateForm() {
    let x = document.forms['connection']['identifiant']['pswd'].value;
    if (x == "") {
      alert('Tous les champs doivent être remplis');
      return false;
    } else {
        submit.submit();
    }
  }