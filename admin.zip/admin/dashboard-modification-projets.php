<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id'])) {
    header("location: connexion.php");
    exit; 
}

$ID=$_GET['id'];

$req = $db->prepare("SELECT * FROM projets WHERE projet_id= '$ID'");
$req->execute();
$projet = $req->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    
    <link rel="stylesheet" href="./assets/css/dash-modif-projets-admin-mobile.css">
    <link rel="stylesheet" href="./assets/css/dash-modif-projets-admin.css">

    <script src="./assets/js/modification-tickets.js" defer></script>
    <script src="./assets/js/sidebar.js" defer></script>    

    <title>MINERVA 🦉 | Modification fiche projet</title>
</head>

<body>
    <div id="box">
        <div class="sidebar"><!--SIDEBAR-->
        <!--menu burger-->
            <img id="burger" src="./assets/img/burger-vertical.svg" alt="Menu burger">
            <img id="burgerHoriz" src="./assets/img/burger-horizontal.svg" alt="Menu burger horizontal">
            <!--image profil-->
            <?php 
            $req = $db->prepare("SELECT * FROM users
            INNER JOIN tickets ON tickets.user_id = users.user_id WHERE users.user_role = 'admin'");
            $req->execute();
            $user = $req->fetchAll(PDO::FETCH_ASSOC);            
            ?>

            <?php foreach ($user as $u):  ?>
            <img id="profil" src="../assets/uploads/<?php echo $u['user_imageprofil']; ?>" alt="Image profil">
            <?php endforeach; ?>
        
        <!-----liens-------->
        <ul class="sidebar__menu">
            <a href="./index.php">
                <div class="sidebar__menu__div" id="tickets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-ticket.svg" alt="Tickets">
                        <a class="sidebar__menu__div__links" href="#">Tickets</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-clients-admin.php">
                <div class="sidebar__menu__div" id="clients">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-clients.svg" alt="Clients">
                        <a class="sidebar__menu__div__links" href="#">Clients</a>
                    </li>
                </div>
            </a>

            <a href="./dashboard-projets-admin.php">
                <div class="sidebar__menu__div" id="projets">
                    <li>
                        <img class="sidebar__menu__div__icons" src="./assets/img/icone-projets.svg" alt="Projets">
                        <a class="sidebar__menu__div__links" href="#">Projets</a>
                    </li>  
                </div> 
            </a>
        </ul> 
        
        <a class="sidebar__btn-side" href="#">+</a>
        </div>
        <!--FIN SIDEBAR-->

        <div id="content">
            <header>
                <a href="./logout.php" class="logout"><img src="../assets/img/log-out.svg" alt="logout"></a>
                <form action="resultats.php" method="GET" name="">
                    <input id="search" type="search" name="search" placeholder="Rechercher..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </form>               
            </header>
            
            <main>       
               

            <!--MODAL Modification FICHE PROJET -->
                <div class="modal-fiche-projet">                
                    <?php foreach ($projet as $p):  ?>
                    <div class="modal-fiche-projet__head">
                        <div class="modal-fiche-projet__head__ensemble-tags">
                            <ul>
                                <li><?php echo $p['projet_type']; ?></li>                              
                            </ul>
                        </div>
                    <div>

                        <div class="modal-fiche-projet__infos">
                            <div id="informations-projet">
                                <p class="modal-fiche-projet__infos__nom"><?php echo $p['projet_client']; ?></p>                                                     
                                <p class="modal-fiche-projet__infos__projet">● <span><?php echo $p['projet_importance']; ?></span></p>
                                <p class="modal-fiche-projet__infos__description"><?php echo $p['projet_description']; ?></p>                                
                            </div>

                            <div id="logo-projet">
                                <p class="modal-fiche-projet__infos__titre">Visuel projet</p>
                                <img class="modal-fiche-projet__infos__logo" src="./assets/uploads/<?php echo $p['projet_visuel']; ?>" alt="visuel">
                            </div>
                        </div>

                        <div class="modal-fiche-projet__form">
                            <form action="modification-projet.php<?php echo '?id='.$p['projet_id']; ?>" method="post"  enctype="multipart/form-data">
                                <div id="main-infos"> 
                                    <label>Importance</label>
                                    <select name="importance" id="impt">
                                        <option value="<?php echo $p['projet_importance'] ?>"><?php echo $p['projet_importance']; ?></option>
                                        <option value="important">Important</option>
                                        <option value="moyen">Moyen</option>
                                        <option value="faible">Faible</option>
                                    </select>                           
                                    <label>Client</label> 
                                    <input type="text" name="client" value="<?php echo $p['projet_client']; ?>">
                                    <label>Type</label> 
                                    <input type="text" name="type" value="<?php echo $p['projet_type']; ?>">
                                    <label>Description</label> 
                                    <textarea name="description"><?php echo $p['projet_description']; ?></textarea>                           
                                </div>

                                <div id="options">                          
                                    <input id="file" type="file" name="fichier" value="<?php echo $p['projet_visuel']; ?>">
                                    <label for="file" id="file-button">Attacher un fichier</label>
                                    <div id="file-upload-filename"><?php echo $p['projet_visuel']; ?></div>
                                </div>

                                <div id="buttons">
                                    <button id="enregistrer-btn">actualiser</button>
                                    <button formaction="suppression-projet.php?id=<?php echo htmlspecialchars($p['projet_id']) ?>" id="supprimer-btn">supprimer</button>
                                </div>                          
                            </form>
                        </div>
                         
                    </div>  
                    <?php endforeach; ?>                  
                </div>         
                
            </main>   
        </div>
    </div> 
</body>
</html>