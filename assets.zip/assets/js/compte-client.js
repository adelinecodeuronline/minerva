//Bouton upload de fichier MODIF PROFIL [COMPTE]
let input = document.querySelector('#file');
input.addEventListener('change', showFileName);
/*Affiche le nom du fichier téléchargé*/
function showFileName(event) {
    let infoArea = document.querySelector('#file-upload-filename');
    let input = event.srcElement; 
    let fileName = input.files[0].name; 

    infoArea.textContent = 'Nom du fichier : ' + fileName;
}

  //Bouton upload de fichier [FORMULAIRE MODAL CREATION TICKET]
  let input2 = document.querySelector('#file2');
  input2.addEventListener('change', showFileName2);
  /*Affiche le nom du fichier téléchargé*/
  function showFileName2(e) {
      let infoArea2 = document.querySelector('#file-upload-filename2');
      let input2 = e.srcElement; 
      let fileName2 = input2.files[0].name; 
  
      infoArea2.textContent = 'Nom du fichier : ' + fileName2;
  }

//CREATION TICKET
//Ouverture modal crea ticket avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-crea-modif');
  modalCrea.style.display = 'block';
}

/////Fermeture modal
document.querySelectorAll('.fermeture').forEach (cross => {
    cross.addEventListener('click', removeModal);
  });
  
  function removeModal() {
    let modalOpened = document.querySelector('.modal-crea-modif');    
    modalOpened.style.display = 'none';    
  }