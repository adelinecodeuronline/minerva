
//CREATION TICKET
//Ouverture modal crea ticket avec pictos bouton '+' sidebar
document.querySelector('.sidebar__btn-side').addEventListener('click', displayModal);

function displayModal() {
  let modalCrea = document.querySelector('.modal-crea-modif');
  modalCrea.style.display = 'block';
}

/////Fermeture modal
document.querySelectorAll('.fermeture').forEach (cross => {
    cross.addEventListener('click', removeModal);
  });
  
  function removeModal() {
    let modalOpened = document.querySelector('.modal-crea-modif');    
    modalOpened.style.display = 'none';    
  }

  //Bouton upload de fichier [FORMULAIRE MODAL CREATION / MODIFICATION TICKET]
let input2 = document.querySelector('#file2');
input2.addEventListener('change', showFileName2);
/*Affiche le nom du fichier téléchargé*/
function showFileName2(e) {
    let infoArea2 = document.querySelector('#file-upload-filename2');
    let input2 = e.srcElement; 
    let fileName2 = input2.files[0].name; 

    infoArea2.textContent = 'Nom du fichier : ' + fileName2;
}

/////////////////////////FAQ

let accBtn = document.getElementsByClassName('faq-menu__accordeon');
let i;

for (i = 0; i < accBtn.length; i++) {
  accBtn[i].addEventListener('click', function() {
    this.classList.toggle('active');
    let panel = this.nextElementSibling;
    if (panel.style.display === 'block') {
      panel.style.display = 'none';
    } else {
      panel.style.display = 'block';
    }
  });
}


