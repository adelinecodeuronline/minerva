////Footer (mobile)
const hand = document.querySelector('#hand');
hand.addEventListener('click', showContact);

function showContact() {
  document.querySelector('#showContact').style.display = 'block';
}

/*Fermeture footer*/
window.addEventListener('click', closeContact);

function closeContact(event) {
if(event.target.matches('#showContact')) {
  document.querySelector('#showContact').style.display = 'none';
}
}
